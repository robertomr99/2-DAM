package unico;

import java.awt.*;
import java.awt.event.*;

public class MiVentana extends java.awt.Frame {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		MiVentana MiApp = new MiVentana();
		MiApp.crearVentana();

	}

	private void crearVentana() {

		addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent we) {
				System.exit(0);
			}
		});

		setTitle("Prueba");
		setBounds(100, 100, 600, 400);
		
		setLayout(null);
		setBackground(Color.gray);
		crearComponentes();
		setVisible(true);
	}

	private void crearComponentes() {

		MenuBar bar = new MenuBar();
		Menu mnuArchivo = new Menu("Archivo");
		Menu mnuEditar = new Menu("Editar");

		bar.add(mnuArchivo);
		bar.add(mnuEditar);
		
		MenuItem mniAbrir = new MenuItem("Abrir");
		MenuItem mniAbrir = new MenuItem("Abrir");
		MenuItem mniAbrir = new MenuItem("Abrir");
		
		
		
		setMenuBar(bar);
		
		
		
		
	}

};
